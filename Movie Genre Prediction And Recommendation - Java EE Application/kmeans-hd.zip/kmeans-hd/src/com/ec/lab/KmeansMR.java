package com.ec.lab;

 import java.net.URI;
import java.util.*;
 import java.io.*;
 import org.apache.hadoop.conf.Configuration;
 import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
 import org.apache.hadoop.fs.Path;
 import org.apache.hadoop.io.*;
 import org.apache.hadoop.mapred.*;
 import org.apache.hadoop.mapred.Reducer;

 @SuppressWarnings("deprecation")
 public class KmeansMR {
     public static String OUT = "outfile";
     public static String IN = "inputlarger";
     public static String CENTROID_FILE_NAME = "/cent.txt";
     public static String OUTPUT_FILE_NAME = "/part-00000";
     public static String DATA_FILE_NAME = "/dataset.txt";
     public static String JOB_NAME = "KMeans";
     public static String SPLITTER = "\t| ";
     

     public static class Map extends MapReduceBase implements
             Mapper<Object, Text, IntWritable, Text> {
    	 public static List<Double[]> mCenters;
    	 
         @Override
         public void configure(JobConf job) {
             try {
                 // Fetch the file from Distributed Cache Read it and store the
                 // centroid in the ArrayList
                 Path[] cacheFiles = DistributedCache.getLocalCacheFiles(job);
                 if (cacheFiles != null && cacheFiles.length > 0) {
                	 
                	 mCenters = readCentroids(cacheFiles[0].toString());
                 }
             } catch (IOException e) {
                 System.err.println("Exception reading DistribtuedCache: " + e);
             }
         }

         @Override
         public void map(Object key, Text value,
                 OutputCollector<IntWritable, Text> output,
                 Reporter reporter) throws IOException {
        	 
        	 
        	 String[] xy = value.toString().split(",");
             double a = Double.parseDouble(xy[0]);
             double b = Double.parseDouble(xy[1]);
             double c = Double.parseDouble(xy[2]);
             double d = Double.parseDouble(xy[3]);
             double e = Double.parseDouble(xy[4]);
             double f = Double.parseDouble(xy[5]);
             double g = Double.parseDouble(xy[6]);
             int index = 0;
             double minDistance = Double.MAX_VALUE;
             for (int j = 0; j < mCenters.size(); j++) {
                // double distance = Utils.euclideanDistance(mCenters.get(j)[0], mCenters.get(j)[1], x, y);
                 double distance = calculateDistance(mCenters.get(j)[0], mCenters.get(j)[1], mCenters.get(j)[2], mCenters.get(j)[3], mCenters.get(j)[4], mCenters.get(j)[5], mCenters.get(j)[6],a, b, c, d, e, f, g);
                 if (distance < minDistance) {
                     index = j;
                     minDistance = distance;
                 }
             }
             
             // Emit the nearest center and the point
             output.collect(new IntWritable(index), value);
         }
         
         public static List<Double[]> readCentroids(String filename) throws IOException {
             FileInputStream fileInputStream = new FileInputStream(filename);
             BufferedReader reader = new BufferedReader(new InputStreamReader(fileInputStream));
             return  readData(reader);
         }
         
         private static List<Double[]> readData(BufferedReader reader) throws IOException {
             List<Double[]> centroids = new ArrayList<>();
             String line;
             try {
                 while ((line = reader.readLine()) != null) {
                     String[] values = line.split("\t");
                     String[] temp = values[0].split(",");
                     Double[] centroid = new Double[8];
                     centroid[0] = Double.parseDouble(temp[0]);
                     centroid[1] = Double.parseDouble(temp[1]);
                     centroid[2] = Double.parseDouble(temp[2]);
                     centroid[3] = Double.parseDouble(temp[3]);
                     centroid[4] = Double.parseDouble(temp[4]);
                     centroid[5] = Double.parseDouble(temp[5]);
                     centroid[6] = Double.parseDouble(temp[6]);
                     centroids.add(centroid);
                 }
             }
             finally {
                 reader.close();
             }
             return centroids;
         }
         
         public static double calculateDistance(double a1, double b1, double c1, double d1, double e1,double f1,double g1, double a2, double b2, double c2, double d2, double e2,double f2,double g2) {
             return Math.sqrt(Math.pow(a1 - a2, 2) + Math.pow(b1 - b2, 2) + Math.pow(c1 - c2, 2) + Math.pow(d1 - d2, 2)+ Math.pow(e1 - e2, 2)+ Math.pow(f1 - f2, 2)+ Math.pow(g1 - g2, 2));
         }
     }

     public static class Reduce extends MapReduceBase implements
             Reducer<IntWritable, Text, Text, IntWritable> {

         @Override
         public void reduce(IntWritable key, Iterator<Text> values,
                 OutputCollector<Text, IntWritable> output, Reporter reporter)
                 throws IOException {
             
             Double ma = 0d;
             Double mb = 0d;
             Double mc = 0d;
             Double md = 0d;
             Double me = 0d;
             Double mf = 0d;
             Double mg = 0d;
             int counter = 0;
        	 
             while (values.hasNext()) {
            	 
            	 String[] temp = values.next().toString().split(",");
                 ma += Double.parseDouble(temp[0]);
                 mb += Double.parseDouble(temp[1]);
                 mc += Double.parseDouble(temp[2]);
                 md += Double.parseDouble(temp[3]);
                 me += Double.parseDouble(temp[4]);
                 mf += Double.parseDouble(temp[5]);
                 mg += Double.parseDouble(temp[6]);
                 counter ++;
             }
        	 
        	 
             // We have new center now
             ma = ma / counter;
             mb = mb / counter;
             mc = mc / counter;
             md = md / counter;
             me = me / counter;
             mf = mf / counter;
             mg = mg / counter;
             String centroid = ma + "," + mb + "," + mc + "," + md+ "," + me+ "," + mf+ "," + mg;
             
             // Emit new center and point
             output.collect(new Text(centroid), key);
         }
     }

     public static void main(String[] args) throws Exception {
         run(args);
     }

     public static void run(String[] args) throws Exception {
         IN = args[0];
         OUT = args[1];
         String input = IN;
         String output = OUT + System.nanoTime();
         //String output = OUT;
         String again_input = output;

         // Reiterating till the convergence
         int iteration = 0;
         boolean hasConverged = false;
         
         
         while (hasConverged == false) {
             JobConf conf = new JobConf(KmeansMR.class);
             if (iteration == 0) {
                 Path hdfsPath = new Path(input + CENTROID_FILE_NAME);
                 // upload the file to hdfs. Overwrite any existing copy.
                 DistributedCache.addCacheFile(hdfsPath.toUri(), conf);
             } else {
                 Path hdfsPath = new Path(again_input + OUTPUT_FILE_NAME);
                 // upload the file to hdfs. Overwrite any existing copy.
                 DistributedCache.addCacheFile(hdfsPath.toUri(), conf);
             }

             conf.setJobName(JOB_NAME);
             conf.setMapOutputKeyClass(IntWritable.class);
             conf.setMapOutputValueClass(Text.class);
             conf.setOutputKeyClass(Text.class);
             conf.setOutputValueClass(IntWritable.class);
             conf.setMapperClass(Map.class);
             conf.setReducerClass(Reduce.class);
             conf.setInputFormat(TextInputFormat.class);
             conf.setOutputFormat(TextOutputFormat.class);

             FileInputFormat.setInputPaths(conf,
                     new Path(input + DATA_FILE_NAME));
             FileOutputFormat.setOutputPath(conf, new Path(output));

             JobClient.runJob(conf);

             Path ofile = new Path(output + OUTPUT_FILE_NAME);
             FileSystem fs = FileSystem.get(new Configuration());
             BufferedReader br = new BufferedReader(new InputStreamReader(
                     fs.open(ofile)));
             
             
             StringBuilder content = new StringBuilder();
            // List<Double> centers_next = new ArrayList<Double>();
             String line = br.readLine();
             while (line != null) {
            	 content.append(line).append("\n");
                 line = br.readLine();
             }
             br.close();
             
             String newCentroids = content.toString();
             
             String prev;
             if (iteration == 0) {
                 prev = input + CENTROID_FILE_NAME;
             } else {
                 prev = again_input + OUTPUT_FILE_NAME;
             }
             Path prevfile = new Path(prev);
             FileSystem fs1 = FileSystem.get(new Configuration());
             BufferedReader br1 = new BufferedReader(new InputStreamReader(
                     fs1.open(prevfile)));
             StringBuilder content1 = new StringBuilder();
             String l = br1.readLine();
             while (l != null) {
            	 content1.append(l).append("\n");
                 l = br1.readLine();
             }
             br1.close();
             
             String prevCentroids = content1.toString();
             
             if (prevCentroids.equals(newCentroids)) {

                 // it means that the iteration is finished
                 hasConverged = true;
             }

            // prevCentroids = newCentroids;
             ++iteration;
             again_input = output;
             output = OUT + System.nanoTime();
             //output = OUT;
         }
     }
 }