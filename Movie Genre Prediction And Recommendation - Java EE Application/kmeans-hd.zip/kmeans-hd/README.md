

# Welcome to the project: Movie Genre Predictions and Recommendations

**Author**: Aman Deep Sharma 


## Introduction and Use

-	In this project kmeans algorith is being used to train the dataset using map reduce in a distributed environment of Hadoop.

-	We need to create jar so that is can be used in our main project to train and save the clusters in HDFS (More details in ec-hd-web project's readme)

-	Right click on th eproject and export is as a jar.

-	Place it at 'C:/tmp/enterprise/hadoop3/' as the below command gets executed when end user click on Initiate hadoop

"C:/enterprise/hadoop-2.7.1/bin/hadoop.cmd", "jar", "C:/tmp/enterprise/hadoop3/kmeans-hd.jar","com.ec.lab.KmeansMR", "/ec","/result13/"

