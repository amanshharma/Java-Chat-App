

# Welcome to the project: Movie Genre Predictions and Recommendations

**Author**: Aman Deep Sharma 

**Technologies**:

-   Hadoop, Kmeans Algorithm and IMDB Dataset.
-   **Java Backend**: Java, Java Rest APIs, Servlets, EJB, Doxygen.
-   **Authentication Server**: Nodejs, Javascript ES6, Node Rest APIs, Express Js, body-parser, msql package.
-   **User Interface**: Reactjs, Javascript ES6, Google's Material UI/UX, Axios Ajax calls, CSS 3.

## Introduction

The project is focused on generating a model which can predict the genre of a movie that a particular user will be into. There are a lot of online websites which take user inputs on different popular movies. The inputs are ratings out of ten from users in most of the cases. I is aimed to train and produce a model that can help to identify a genre if given some input ratings based on the datasets from websites like imdb.com and rottentomatoes.com.

The dataset that will be used will contain ratings of movies from three different genre i.e. Horror, Comedy and Science fiction. I will pick two or more movie ratings from each genre and the overall interest of a user. There will be a distinct user like i.e no two or more genre like belongs to the same user.

K means algorithm is used to train the model. The model is being trained on the basis of dataset and three clusters will be created based on the genres. Based on the inputs of ratings from a new user, the model will be able to predict the genre for the user and based on that information we can provide recommendations to the user for more movies. This kind of a model can be very helpful for websites where users give ratings and meanwhile see some recommendations that they could be interested in.

## Environment Setup

 1. [ ] Start the Node js Authentication Server. By default the server will be running on port 5000. Please follow the instructions from Node Server setup document.
 2. [ ] Create Kmeans-hd jar by following the instructions in readme file of kmeans-hd java project.
 3. [ ] Run the ec-hd-web project on server.
 4. [ ] Once the project is up and running. Please go to the web browser and test if Rest APIs are working fine.
 5. [ ] Open URL http://localhost:8080/ec-hd-web/rest/test. This will display a JSON object on UI 
 {
  "result": "Welcome to the enterprise project"
}
That means the service is up and running.
 6. [ ] Now, finally start the UI web application built with Reactjs. Follow the instruction in Web app document attached with project submission.

##	Rest APIs offered by the Java application

Important node: By default chrome browser does not allow Cross origin api access for any react app. To enable this please run the react app using the instructions in react app read me file. In short please open the chrome using the below command that would allo CORS:

**C:\Program Files (x86)\Google\Chrome\Application>chrome.exe --user-data-dir="C:/Chrome dev session" --disable-web-security**

Assuming your chrome is installed at C:\Program Files (x86)\Google\Chrome\Application>

This will not be a problem if we buy a dedicated public domain in real case scenario. In our scenario here chrome will not allow Localhost cross origins.
 

 *To test the API server*:
 
	 Type: Get
	 Path: test
	 URL: http://localhost:8080/ec-hd-web/rest/test
	 Consumes: N/A
	 Produces: text/json
	 
  *To invoke hadoop and create clusters based on the dataset and centroids defined*:
  
	 Type: Get
	 Path: invokehadoop
	 URL: http://localhost:8080/ec-hd-web/rest/invokehadoop
	 Consumes: N/A
	 Produces: text/json
 
  *To create and save the Model*:
  
	 Type: Post
	 Path: invokehadoop
	 URL: http://localhost:8080/ec-hd-web/rest/ppost
	 Consumes: JSON
	 Produces: Plain Text
 
 *To predict the result using the created model based on the inputs from UI*:
 
	 Type: Post
	 Path: predict
	 URL: http://localhost:8080/ec-hd-web/rest/predict
	 Consumes: JSON
	 Produces: Plain Text
	 
## Steps to run the full application

-	Few users have already been added in the database:

	ID	Username	Password	Role
	1	aman		aman		1
	2	jhon		jhon		2
	3	bob		bob		2
	
Role 1. Represents he/she is Admin and has the rights to Invoke Hadoop and Build/save the model.

Role 2. Role 2 is for the End User, who can view the the web app prediction and recommendation page and use to predict the genreand use the feature of viewing the trailers based on the predicted genre.

**As a prerequisite** Please start the Hadoop in comand line and make dataset and centroid file ready.

-	**Login Page**

Please enter username: 'aman' and password: 'aman', we will be logged in as an Admin.

-	**Admin Page**

In this page we have first button that says "Initiate". This button will start the Hadoop that will use "Kmeans-hd.jar" to trains based on the dataset using kmeans Algorithm and stores a file i.e model clusters in hdfs.

**Note:** Before Initiating please make sure the below mentioned steps.

-	In hdfs **/ec/cent.txt** must be present with the centroids information like the one attached with the project.
-	In hdfs **/ec/dataset.txt** must be present that contains the dataset values to train the model. It is also attached in the project.
-	The resulted model clusters will be stored in **/result13/** in HDFS. Please check the **/part-00000** file with correct path inside **/result13/**

After the Clusters are created in the HDFS. Now, we are ready to Build and Save our generated Model in the file as per the project requirements.

Enter the path in the text box. It would look like this **/result11/963611346192103/part-00000** Please make sure it before entering by going into the HDFS.

Click on the **create model** button. This will save the model **bin** file in file system at path **C:/tmp/enterprise/model/** as **kmeans.bin**.

**Note:** The above creation model uses the jar : KmeansHDFSClient.jar, so please create the jar from the attached code and put it at **C:/tmp/enterprise/hadoop3**. This will use the clusters file as an argument to create and save the model.

Finally, we have a **Logout** button to logoff from the admin page.

-	**Enter User page (Application feature)**

Now, login as an end user, username: 'jhon' and password: 'jhon'

User will be taken to the Application user page. In this page we have put six different movie posters with an input field below, respectively. The inputs are basically the rating accorting to the user i.e. what user feels about that movie. The rating will be out of 10. It coul be a decimal value. 

These six values will be used to feed our Model so that it can Predict the **GENRE** of that particular user. 

The first two Movies are from **Sci Fi** Genre: **Harry Potter** and **Interstellar**

The next two Movies are from **Comedy** Genre: **Jhonny English** and **The Mask**

The last two Movies are from **Horror** Genre: **Lights Out** and **The Nun** 

After The end user gives the ratings out of 10, He/she can click on Submit button.

After this the prediction on Hadoop will be initiated and a result will be returned.

It could be **Sci fi**, **Comedy** or **Horror**

Based on the results the recommendation panel in the **right bottom** panel will be updated.

User can click on the recommended movie in the panel and he can view the **Trailer** in the right top pane.

**Logout Button** can be used if user wants to Logoff from the application.

## JUNIT Java Test Cases

**testScifiGenre**

-	This test case is to test the sci fi genre prediction

**testComedyGenre**

-	This test case is to test the Comedy genre prediction

**testHorrorGenre**

-	This test case is to test the Horror genre prediction


** To create the dcument please right click on doxyfile and select Build documentation**

Finally, check in the HTML folder generated and open Index.htlm to view the documentation.


## Logger - Winston logger is used in Nodejs server.

All the logs will be saves in results.log file in Node server.

 