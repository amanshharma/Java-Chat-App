package com.ec.lab;

import javax.ejb.Local;

/** 
* @class ECHDSingletonLocal
* @brief This is the local interface for ECHDSingleton class
* @file ECHDSingletonLocal.java
*/ 
@Local
public interface ECHDSingletonLocal {

	/**
	  * @brief Build kmeans model. 
	  */ 
	 String buildModel();
	
	 /**
	  * @brief creating model. 
	  */ 
	 void createModel(String inputLocation);


}
