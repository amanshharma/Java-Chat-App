package com.ec.lab;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/** 
* @class ECHDSingleton
* @brief This class implements the logic for building and creating the model.
* 
*/
@Singleton
@LocalBean
public class ECHDSingleton implements ECHDSingletonRemote, ECHDSingletonLocal {

	/**
	  * @brief constructor.
	  */ 
    public ECHDSingleton() {
        // TODO Auto-generated constructor stub
    }
    
    /**
	  * @brief This method starts Hadoop and initiates the cluster formation using kmeans-hd.jar and stores the results.
	  * 
	  * @param none
	  */ 
    @Override
    public String buildModel() {
		System.out.println("Inside Singleton");
		try {
			ProcessBuilder pb = new ProcessBuilder("C:/enterprise/hadoop-2.7.1/bin/hadoop.cmd", "jar", "C:/tmp/enterprise/hadoop3/kmeans-hd.jar","com.ec.lab.KmeansMR", "/ec","/result13/");		
			pb.start();
			  
			  
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Invoke hadoop"); 
		return "completed";	 
    }
    
    /**
	  * @brief This method creates and saves the model bin file
	  * 
	  * @param Input Location
	  */ 
    @Override
    public void createModel(String inputLocation) {
    	///result11/963611346192103/part-00000
    	System.out.println("Inside Singleton");
		try {
			ProcessBuilder pb = new ProcessBuilder("java", "-jar", "C:/tmp/enterprise/hadoop3/KmeansHDFSClient.jar",inputLocation);		
    		//pb.directory(new File("C:/tmp/enterprise/model"));
    		pb.start();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
    	 System.out.println("create model" +inputLocation);
    	 
     }  
    
}