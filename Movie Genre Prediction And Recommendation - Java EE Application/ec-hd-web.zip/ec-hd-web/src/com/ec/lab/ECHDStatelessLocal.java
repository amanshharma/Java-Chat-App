package com.ec.lab;

import java.io.IOException;

import javax.ejb.Local;

/** 
* @class ECHDStatelessLocal
* @brief This is the local interface for ECHDStateless class
* @file ECHDStatelessLocal.java
*/ 
@Local
public interface ECHDStatelessLocal {

	/**
	  * @brief Predicting DataModel 
	  */ 
  String predict(double value1, double value2, double value3, double value4, double value5, double value6) throws IOException;
}
