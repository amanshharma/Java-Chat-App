package com.ec.lab;

import javax.ejb.Remote;

/** 
* @class ECHDSingletonRemote
* @brief This is the remote interface for ECHDSingleton class
* @file ECHDSingletonLocal.java
*/ 
@Remote
public interface ECHDSingletonRemote {

	/**
	  * @brief Build kmeans model. 
	  */ 
	 String buildModel();
	
	 /**
	  * @brief creating model. 
	  */ 
	 void createModel(String inputLocation);
	

}
