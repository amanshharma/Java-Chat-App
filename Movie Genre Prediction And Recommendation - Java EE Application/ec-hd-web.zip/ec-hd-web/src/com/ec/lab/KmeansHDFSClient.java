package com.ec.lab;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
/** 
* @class KmeansHDFSClient
* @brief This class has the logic for getting a path and then saving the Model.
* 
*/
public class KmeansHDFSClient {

	public static void main(String[] args) throws IOException {

		String hdfsPath = "hdfs://localhost:9000";

		Configuration conf = new Configuration();
		conf.set("fs.defaultFS", hdfsPath);
	
		FileSystem fs = FileSystem.get(conf);
		
		//Path path = new Path("/output2/96008519473729/part-00000");
		Path path = new Path(args[0]);
		if (!fs.exists(path)) {
			System.out.println("file does not exist");
		}
		else {
			FSDataInputStream in = fs.open(path);
			byte[] b = new byte[1024];
			int numBytes = 0;
			String s = new String();
			while ((numBytes = in.read(b)) > 0) {
				s += new String(b);

			}
			
			String[] data = s.split("\t");
			
			List<String> objList = new ArrayList<String>();
			for(String value : data){
				if(value.contains("\n")){
					String[] res = value.split("\n");
					if(!res[1].isEmpty())
						objList.add(res[1]);
				}
				else{
					objList.add(value);
				}
				
			}
			
			//create objetc of main cluster
			KmeanCluster objCluster = new KmeanCluster();
			List<Model> list_Model = new ArrayList<Model>();
			
			for(String value : objList){
				if(!value.isEmpty() && !value.equals("") && !value.equals(null) && value.contains(",")){
					String[] res = value.split(",");
					Model objModel = new Model();
					double[] data_list = new double[7];
					data_list[0] = Double.parseDouble(res[0]);
					data_list[1] = Double.parseDouble(res[1]);
					data_list[2] = Double.parseDouble(res[2]);
					data_list[3] = Double.parseDouble(res[3]);
					data_list[4] = Double.parseDouble(res[4]);
					data_list[5] = Double.parseDouble(res[5]);
					data_list[6] = Double.parseDouble(res[6]);
					objModel.setDataValue(data_list);					
					list_Model.add(objModel);
				}	
			}
			objCluster.setData(list_Model);
			
			
			FileOutputStream fileoutputstream = new FileOutputStream("C:/tmp/enterprise/model/kmeans.bin");
			
	    	ObjectOutputStream oboutputstream = new ObjectOutputStream(fileoutputstream);
	    	oboutputstream.writeObject(objCluster);
	    	fileoutputstream.close();
	    	oboutputstream.close();
			
			in.close();
			
			System.out.println("Model has been saved!!!");
		}
	}
}