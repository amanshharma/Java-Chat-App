package com.ec.lab;

import java.io.Serializable;
/** 
* @class Model
* @brief Plain java class for data value.
* 
*/
public class Model implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private double[] dataValue;
	
	public double[] getDataValue() {
		return dataValue;
	}

	public void setDataValue(double[] dataValue) {
		this.dataValue = dataValue;
	}

	public Model() {
        super();
    }
	
	
	
	
}
