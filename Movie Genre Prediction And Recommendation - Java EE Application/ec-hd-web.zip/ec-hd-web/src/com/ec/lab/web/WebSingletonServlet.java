package com.ec.lab.web;
import java.io.File;
import java.io.IOException;

import java.io.IOException;
import java.io.PrintWriter;


import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ec.lab.ECHDSingletonRemote;
import com.ec.lab.ECHDStatelessRemote;

/** 
* @class WebSingletonServlet
* @brief Servlet class for handling the requests from UI
* 
*/

@WebServlet("/WebSingletonServlet")
public class WebSingletonServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @EJB
    private ECHDSingletonRemote singleton;
    @EJB
    private ECHDStatelessRemote stateless;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        try {
            
            int value = Integer.parseInt(request.getParameter("value"));
 
          if (value == 1) {
                out.println("<br><br><h3>Invoke Hadoop<br><br>");
                String result = "Traing the data...";
                out.println("<br>"+result+"<br>");
                result = singleton.buildModel();
                out.println("<br>"+result+"<br>");
            } 
            else if (value == 2) 
            {
            	  String path = request.getParameter("pathLocation");
            	  out.println("<br><br><h3>Creating Model...<br><br>");   
            	  out.println(path);
            	  singleton.createModel(path);
            }
            else
            {
        		  double val_one = Double.parseDouble(request.getParameter("val_one"));
        		  double val_two = Double.parseDouble(request.getParameter("val_two"));
        		  double val_three = Double.parseDouble(request.getParameter("val_three"));
        		  double val_four = Double.parseDouble(request.getParameter("val_four"));
        		  double val_five = Double.parseDouble(request.getParameter("val_five"));
        		  double val_six = Double.parseDouble(request.getParameter("val_six"));
            	  out.println("<br><br><h3>Predict<br>");
            	  out.println("value one : "+val_one+"<br>value two : "+val_two+"<br>value three : "+val_three);
            	  String predict_result = stateless.predict(val_one, val_two, val_three, val_four, val_five, val_six);
            	  out.println("<br><br><h3>Predict Value:  "+predict_result+"<br>");
            }

           

        } catch (Exception ex) {
            throw new ServletException(ex);
        } finally {
            out.close();
        }
    }
}