package com.ec.lab;

import java.io.IOException;

import javax.ejb.Remote;

/** 
* @class ECHDStatelessRemote
* @brief This is the local interface for ECHDStateless class
* @file ECHDStatelessRemote.java
*/ 
@Remote
public interface ECHDStatelessRemote {

	/**
	  * @brief Predicting DataModel 
	  */ 
	String predict(double value1, double value2, double value3, double value4, double value5, double value6) throws IOException;
}
