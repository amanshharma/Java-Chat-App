package com.ec.lab;

import java.io.IOException;

import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

/** 
* @class ECRS
* @brief This class contains all the rest based APIs
* @file ECRS.java
*/
@Path("/")
@RequestScoped
public class ECRS {  
    @EJB
    ECHDSingletonRemote singleton;
    
    @EJB
    ECHDStatelessRemote stateless;
    
    /**
	  * @brief This API consumes get request and calls buildModel method of singleton class
	  * 
	  * 
	  */ 
    @GET
    @Path("/invokehadoop")
    @Produces("text/json")
    public String invoke(@QueryParam("value") String value) {
    	
    	String result = singleton.buildModel();
    	return "{\"result\":\""+result.toString()+"\"}";
    } 
    
    /**
	  * @brief This is a test API, that produces 'Welcome to the enterprise project message'
	  * 
	  * 
	  */ 
    @GET
    @Path("/test")
    @Produces("text/json")
    public String invoke2(@QueryParam("value") String value) {
    	
    	String result = singleton.buildModel();
    	return "{\"result\":\"Welcome to the enterprise project\"}";
    } 
    
    /**
	  * @brief This API consumes post request and calls createModel method of singleton class
	  * 
	  * 
	  */ 
    @POST
    @Path("/ppost")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.TEXT_PLAIN)
    public void createCustomer(String newCustomer) {
    	System.out.println(newCustomer.split("\"")[3]);
    	String path = newCustomer.split("\"")[3];
    	System.out.println(path);
    	singleton.createModel(path);
    }
    
    /**
	  * @brief This API consumes post request and calls predict method of stateless class
	  * 
	  * 
	  */ 
    @POST
    @Path("/predict")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.TEXT_PLAIN)
    public String createCustome(String data) {
    	System.out.println(data);
    
    	String valueArray[] = data.split(",");
    	
    		System.out.println(valueArray[0].split(":")[1].split("\"")[1]);
    		System.out.println(valueArray[1].split(":")[1].split("\"")[1]);
    		System.out.println(valueArray[2].split(":")[1].split("\"")[1]);
    		System.out.println(valueArray[3].split(":")[1].split("\"")[1]);
    		System.out.println(valueArray[4].split(":")[1].split("\"")[1]);
    		System.out.println(valueArray[5].split(":")[1].split("\"")[1]);
    		
    		double val_one = Double.parseDouble(valueArray[0].split(":")[1].split("\"")[1]);
   		  	double val_two = Double.parseDouble(valueArray[1].split(":")[1].split("\"")[1]);
   		  	double val_three = Double.parseDouble(valueArray[2].split(":")[1].split("\"")[1]);
   		  	double val_four = Double.parseDouble(valueArray[3].split(":")[1].split("\"")[1]);
   		  	double val_five = Double.parseDouble(valueArray[4].split(":")[1].split("\"")[1]);
   		  	double val_six = Double.parseDouble(valueArray[5].split(":")[1].split("\"")[1]);
   		  	
   		  	String predict_result = "null";
			try {
				predict_result = stateless.predict(val_one, val_two, val_three, val_four, val_five, val_six);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	   		 System.out.println(predict_result);
	   		return "{\"result\":\""+predict_result+"\"}";

    }
    
    
    

}