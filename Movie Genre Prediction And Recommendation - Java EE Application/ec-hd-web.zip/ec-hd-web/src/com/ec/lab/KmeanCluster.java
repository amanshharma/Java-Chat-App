package com.ec.lab;

import java.io.Serializable;
import java.util.List;
/** 
* @class KmeanCluster
* @brief plain class for object value
* 
*/
public class KmeanCluster implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private List<Model> obvalue;
	
	public KmeanCluster() {
        super();
    }
	
	
	
	public final List<Model> getData() {
        return obvalue;
    }
	
	
	 
	 public final void setData(List<Model> obvalue) {
		 this.obvalue = obvalue;
	 }
}
