package com.ec.lab;
import java.io.File;
import java.io.IOException;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Scanner;

/** 
* @class ECHDStateless
* @brief This class implements the logic for building and creating the model.
* 
*/
@Stateless
@LocalBean
public class ECHDStateless implements ECHDStatelessRemote, ECHDStatelessLocal {

	/**
	  * @brief constructor.
	  */ 
    public ECHDStateless() {
        // TODO Auto-generated constructor stub
    }

    
    /**
	  * @brief This method is to predict the value after a user gives the input ratings for 6 movies
	  * 
	  * @param movie rating val 1, movie rating val 2, movie rating val 3, movie rating val 4, movie rating val 5, movie rating val 6
	  */
	@Override
	public String predict(double value1, double value2, double value3, double value4, double value5, double value6)
			throws IOException {
		// TODO Auto-generated method stub
		System.out.println(value1);
    	System.out.println(value2);
    	System.out.println(value3);
    	System.out.println(value4);
    	System.out.println(value5);
    	System.out.println(value6);
    	


		FileInputStream streamIn = null;
    	ObjectInputStream objectinputstream = null;
    	KmeanCluster readCase = new KmeanCluster();
    	try {
    	    streamIn = new FileInputStream("C:/tmp/enterprise/model/kmeans.bin");
    	    objectinputstream = new ObjectInputStream(streamIn);
    	    readCase = (KmeanCluster) objectinputstream.readObject();
    	    //recordList.add(readCase);
    	    
    	} catch (Exception e) {
    	    e.printStackTrace();
    	} finally {
    	    if(objectinputstream != null){
    	        objectinputstream .close();
    	        streamIn.close();
    	    } 
    	}
    	//ClusterModel objCluster = new ClusterModel();
    	double[] arr_data = new double[6];
    	arr_data[0] = value1;
    	arr_data[1] = value2;
    	arr_data[2] = value3;
    	arr_data[3] = value4;
    	arr_data[4] = value5;
    	arr_data[5] = value6;
    	
    	int a = 0;
    	int b = 0;
    	int c = 0;
    	int d = 0;
    	int e = 0;
    	int f = 0;
    	
    	double[] disa = new double[readCase.getData().size()];
    	for(Model objModel : readCase.getData()){
    		disa[a] = Math.abs(arr_data[0] - objModel.getDataValue()[0]);
    		a++;
    	}
    	
    	double[] disb = new double[readCase.getData().size()];
    	for(Model objModel : readCase.getData()){
    		disb[b] = Math.abs(arr_data[1] - objModel.getDataValue()[1]);
    		b++;
    	}
    	
    	double[] disc = new double[readCase.getData().size()];
    	for(Model objModel : readCase.getData()){
    		disc[c] = Math.abs(arr_data[2] - objModel.getDataValue()[2]);
    		c++;
    	}
    	
    	double[] disd = new double[readCase.getData().size()];
    	for(Model objModel : readCase.getData()){
    		disd[d] = Math.abs(arr_data[3] - objModel.getDataValue()[3]);
    		d++;
    	}
    	
    	double[] dise = new double[readCase.getData().size()];
    	for(Model objModel : readCase.getData()){
    		dise[e] = Math.abs(arr_data[4] - objModel.getDataValue()[4]);
    		e++;
    	}
    	
    	double[] disf = new double[readCase.getData().size()];
    	for(Model objModel : readCase.getData()){
    		disc[f] = Math.abs(arr_data[5] - objModel.getDataValue()[5]);
    		f++;
    	}
    	
    	int counter[] = new int[readCase.getData().size()];
    	
    	for(int coun : counter){
    		coun = 0;
    	}
    	
    	for(int j=0; j<disa.length-1; j++){
    		if(disa[j]>0 && disa[j+1]>0){
    			if(disa[j] < disa[j+1]){
        			counter[j]++;
        		}else{
        			counter[j+1]++;
        		}
    		}
    	}
    	
    	for(int j=0; j<disb.length-1; j++){
    		if(disb[j]>0 && disb[j+1]>0){
    			if(disb[j] < disb[j+1]){
        			counter[j]++;
        		}else{
        			counter[j+1]++;
        		}
    		}		
    	}
    	
    	for(int j=0; j<disc.length-1; j++){
    		if(disc[j]>0 && disc[j+1]>0){
    			if(disc[j] < disc[j+1]){
        			counter[j]++;
        		}else{
        			counter[j+1]++;
        		}
    		}		
    	}
    	
    	for(int j=0; j<disd.length-1; j++){
    		if(disd[j]>0 && disd[j+1]>0){
    			if(disd[j] < disd[j+1]){
        			counter[j]++;
        		}else{
        			counter[j+1]++;
        		}
    		}		
    	}
    	
    	for(int j=0; j<dise.length-1; j++){
    		if(dise[j]>0 && dise[j+1]>0){
    			if(dise[j] < dise[j+1]){
        			counter[j]++;
        		}else{
        			counter[j+1]++;
        		}
    		}		
    	}
    	
    	for(int j=0; j<disf.length-1; j++){
    		if(disf[j]>0 && disf[j+1]>0){
    			if(disf[j] < disf[j+1]){
        			counter[j]++;
        		}else{
        			counter[j+1]++;
        		}
    		}		
    	}
    	
    	int min = counter[0];
    	int near = 0;
    	
    	for(int j=1;j<disa.length;j++){
    		if(min < counter[j]){
    			min = counter[j];
    			near = j;
    		}
    	}
    	
    	System.out.println("\nThe predicted 4th value is ..." + readCase.getData().get(near).getDataValue()[6]);
    	return ""+readCase.getData().get(near).getDataValue()[6];
    
	}

   
      
    
}