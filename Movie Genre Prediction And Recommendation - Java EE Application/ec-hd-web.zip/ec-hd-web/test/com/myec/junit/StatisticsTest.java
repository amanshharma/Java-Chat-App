package com.myec.junit;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import javax.ejb.EJB;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.ec.lab.ECHDSingletonRemote;
import com.ec.lab.ECHDStateless;

/** 
* @class StatisticsTest
* @brief This class implements the logic for JUNIT test cases.
* 
*/
public class StatisticsTest {
	
	@EJB
    ECHDSingletonRemote singleton;
    
    
    ECHDStateless stateless = new ECHDStateless();
		

    
	ArrayList<Double> dataArray;

	@BeforeClass
	public static void myStatistics() {
		//statistics = new Statistics(); 
	}
	
	@Before
	public void beforeEachTest() {
		System.out.println("This is executed before each Test");
	}

	@After
	public void afterEachTest() {
		System.out.println("This is exceuted after each Test");
		
	}
	
	@Test
	public void testScifiGenre() {
		try {
			assertEquals("1.0", stateless.predict(8.1, 9.1, 3.9, 4, 4.1, 4.1));	
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}
	}
	
	@Test
	public void testComedyGenre() {
		try {
			assertEquals("2.0", stateless.predict(3.9, 4, 8.1, 9.1, 4.1, 4.2));	
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}
	}
	
	@Test
	public void testHorrorGenre() {
		try {
			assertEquals("3.0", stateless.predict(2, 3, 4, 5, 8, 9));	
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}
	}
	

}

