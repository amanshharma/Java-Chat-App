var searchData=
[
  ['getdata',['getData',['../classcom_1_1ec_1_1lab_1_1_kmean_cluster.html#a7b4bf71165580da68712d47b869d7461',1,'com::ec::lab::KmeanCluster']]],
  ['getdatavalue',['getDataValue',['../classcom_1_1ec_1_1lab_1_1_model.html#aa5580bf26c35dc7f9d6e577fdf310291',1,'com::ec::lab::Model']]]
];
