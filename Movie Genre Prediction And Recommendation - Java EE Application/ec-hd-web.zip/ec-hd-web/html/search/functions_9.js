var searchData=
[
  ['setdata',['setData',['../classcom_1_1ec_1_1lab_1_1_kmean_cluster.html#acaba1997b5bd50881dcd4fea1441a6d7',1,'com::ec::lab::KmeanCluster']]],
  ['setdatavalue',['setDataValue',['../classcom_1_1ec_1_1lab_1_1_model.html#aa9053259f4c658408d2ebf12ac459878',1,'com::ec::lab::Model']]]
];
